import pygame as pg
vec = pg.math.Vector2

# cores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
DARKGREY = (40, 40, 40)
LIGHTGREY = (100, 100, 100)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
YELLOW = (255, 255, 0)

# definições da janela do jogo
WIDTH = 1280
HEIGHT = 720
FPS = 60
TITLE = "The Living Dead Meme"
BGCOLOR = DARKGREY

TILESIZE = 64
GRIDWIDTH = WIDTH / TILESIZE
GRIDHEIGHT = HEIGHT / TILESIZE

WALL_IMG = 'tilewall.png'

#definições do jogador
PLAYER_HEALTH = 100
PLAYER_SPEED = 350
PLAYER_ROT_SPEED = 250
PLAYER_IMG = 'player.png'
PLAYER_HIT_RECT = pg.Rect(0, 0, 64, 64)
ORIGIN_OFFSET = vec(68, 2)

#propriedades das 2 armas do jogo
PROJECTILE_IMG = 'projectile.png'
WEAPONS = {}
WEAPONS['machine gun'] = {'projectile_speed': 500,
'projectile_lifetime': 1000,
'rate': 200,
'kickback': 0,
'spread': 5,
'damage': 10,
'projectile_size': 'lg',
'projectile_count': 1}
WEAPONS['shotgun'] = {'projectile_speed': 400,
'projectile_lifetime': 500,
'rate': 900,
'kickback': 1000,
'spread': 20,
'damage': 4,
'projectile_size': 'sm',
'projectile_count': 12}

#opções dos inimigos
MOB_IMAGE = 'mob.png'
MOB_SPEEDS = [250, 300, 350, 400, 420]
MOB_HIT_RECT = pg.Rect(0, 0, 30, 30)
MOB_HEALTH = 50
MOB_DAMAGE = 10
MOB_KNOCKBACK = 25
AVOID_RADIUS = 50
DETECT_RADIUS = 600

#efeitos visuais
SPLAT = 'poo in the loo.png'
DAMAGE_ALPHA = [i for i in range(0, 255, 55)]
NIGHT_COLOR = (10, 10, 10)
LIGHT_RADIUS = (500, 500)
LIGHT_MASK = "light.png"

#definição de camadas, que objetos tem prioridade acima dos outros
WALL_LAYER = 1
PLAYER_LAYER = 2
PROJECTILE_LAYER = 3
MOB_LAYER = 2
EFFECTS_LAYER = 4
ITEMS_LAYER = 1

#itens colecionáveis
ITEM_IMAGES = {'health': 'health.png',
               'shotgun': 'weaponpickup.png'}
HEALTH_PACK_AMOUNT = 20
BOB_RANGE = 20
BOB_SPEED = 0.5

#sons e música de fundo
BG_MUSIC = 'e1m1.mp3'
PLAYER_HIT_SOUND = ['OOF.wav']
ENEMY_HIT_SOUND = ['splat.wav']
UGANDAN_SOUND = ['dewae.wav', 'click.wav']
WEAPON_SOUNDS = {'machine gun': ['bullet.wav'], 'shotgun': ['shotgun.wav']}
EFFECTS_SOUNDS = {'health_up': 'health_pack.wav',
                  'gun_pickup': 'gun_pickup.wav'}